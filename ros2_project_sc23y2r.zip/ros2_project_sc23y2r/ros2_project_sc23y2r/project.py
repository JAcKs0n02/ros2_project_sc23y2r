import math
import time

import cv2
import numpy as np
import rclpy
from action_msgs.msg import GoalStatus
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import PoseWithCovarianceStamped, Twist
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image, LaserScan


INITIAL_POSE = (-2.0, 0.5, 0.0)

SEARCH_WAYPOINTS = [
    (-6.0, 3.5, 2.4),
    (-9.0, -2.0, -1.6),
    (-5.0, -7.0, 0.0),
    (-1.0, -3.0, 1.5),
    (-6.0, 3.5, 2.4),
]

MIN_AREA = 500
TARGET_BLUE_DISTANCE = 0.95
STOP_BLUE_DISTANCE = 0.80
BLUE_STOP_AREA_FALLBACK = 130000
FRONT_SCAN_HALF_ANGLE = 0.18
BLUE_RECENT_SECONDS = 0.8


def yaw_to_quaternion(yaw):
    return 0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)


class ProjectNode(Node):
    def __init__(self):
        super().__init__('ros2_project_sc23y2r')

        self.bridge = CvBridge()

        image_qos = QoSProfile(depth=10)
        image_qos.reliability = ReliabilityPolicy.RELIABLE

        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            image_qos,
        )
        
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10,
        )

        self.front_distance = float('inf')
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.initial_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped,
            '/initialpose',
            10,
        )

        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        self.window_name = 'processed_camera_feed'
        cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.window_name, 640, 480)

        self.seen_red = False
        self.seen_green = False
        self.seen_blue = False

        self.current_red = False
        self.current_green = False
        self.current_blue = False

        self.image_width = 960
        self.blue_x = None
        self.blue_area = 0
        self.last_blue_time = 0.0

        self.state = 'STARTING'
        self.goal_handle = None
        self.goal_active = False
        self.cancel_requested = False
        self.waypoint_index = 0

        self.initial_pose_count = 0
        self.start_time = time.time()

        self.timer = self.create_timer(0.2, self.control_loop)

    def control_loop(self):
        if self.initial_pose_count < 8:
            self.publish_initial_pose()
            self.initial_pose_count += 1
            return

        if self.state == 'STARTING':
            if not self.nav_client.wait_for_server(timeout_sec=0.1):
                self.state = 'WAITING_FOR_NAV2'
                return
            self.state = 'SEARCHING'
            self.send_next_waypoint()
            return

        if self.state == 'WAITING_FOR_NAV2':
            if self.nav_client.wait_for_server(timeout_sec=0.1):
                self.state = 'SEARCHING'
                self.send_next_waypoint()
            return

        if self.seen_blue and self.state in ('SEARCHING', 'NAVIGATING'):
            self.state = 'APPROACHING_BLUE'
            self.cancel_nav_goal()
            self.stop_robot()
            return

        if self.state == 'APPROACHING_BLUE':
            self.approach_blue()
            return

        if self.state == 'FINISHED':
            self.stop_robot()
            return

        if self.state == 'SEARCHING' and not self.goal_active:
            self.send_next_waypoint()

    def publish_initial_pose(self):
        x, y, yaw = INITIAL_POSE
        qx, qy, qz, qw = yaw_to_quaternion(yaw)

        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x = x
        msg.pose.pose.position.y = y
        msg.pose.pose.position.z = 0.0
        msg.pose.pose.orientation.x = qx
        msg.pose.pose.orientation.y = qy
        msg.pose.pose.orientation.z = qz
        msg.pose.pose.orientation.w = qw

        msg.pose.covariance = [
            0.25, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.25, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.0, 0.0, 0.0, 0.0, 0.0, 0.0685,
        ]

        self.initial_pose_pub.publish(msg)
        self.get_logger().info(
            f'Published initial pose x={x:.2f}, y={y:.2f}, yaw={yaw:.2f}'
        )

    def send_next_waypoint(self):
        if not self.nav_client.server_is_ready():
            return

        x, y, yaw = SEARCH_WAYPOINTS[self.waypoint_index]
        self.waypoint_index = (self.waypoint_index + 1) % len(SEARCH_WAYPOINTS)

        qx, qy, qz, qw = yaw_to_quaternion(yaw)

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        goal_msg.pose.pose.position.z = 0.0
        goal_msg.pose.pose.orientation.x = qx
        goal_msg.pose.pose.orientation.y = qy
        goal_msg.pose.pose.orientation.z = qz
        goal_msg.pose.pose.orientation.w = qw

        self.state = 'NAVIGATING'
        self.goal_active = True
        self.cancel_requested = False

        self.get_logger().info(f'Sending Nav2 goal: x={x:.2f}, y={y:.2f}, yaw={yaw:.2f}')

        future = self.nav_client.send_goal_async(goal_msg)
        future.add_done_callback(self.nav_goal_response_callback)

    def nav_goal_response_callback(self, future):
        self.goal_handle = future.result()

        if not self.goal_handle.accepted:
            self.get_logger().warn('Nav2 goal rejected')
            self.goal_active = False
            self.state = 'SEARCHING'
            return

        self.get_logger().info('Nav2 goal accepted')
        result_future = self.goal_handle.get_result_async()
        result_future.add_done_callback(self.nav_result_callback)

    def nav_result_callback(self, future):
        self.goal_active = False

        if self.state == 'APPROACHING_BLUE':
            return

        result = future.result()
        status = result.status

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info('Nav2 goal reached')
        else:
            self.get_logger().warn(f'Nav2 goal ended with status {status}')

        self.state = 'SEARCHING'

    def cancel_nav_goal(self):
        if self.goal_handle is None or not self.goal_active or self.cancel_requested:
            return

        self.cancel_requested = True
        self.get_logger().info('Cancelling Nav2 goal because blue was detected')
        self.goal_handle.cancel_goal_async()

    def approach_blue(self):
        now = time.time()

        if now - self.last_blue_time > BLUE_RECENT_SECONDS:
            cmd = Twist()
            cmd.angular.z = 0.25
            self.cmd_vel_pub.publish(cmd)
            return

        centre_x = self.image_width / 2.0
        error = (self.blue_x - centre_x) / centre_x

        blue_centred = abs(error) < 0.15
        close_by_lidar = self.front_distance <= STOP_BLUE_DISTANCE
        close_by_camera = self.blue_area >= BLUE_STOP_AREA_FALLBACK

        if blue_centred and (close_by_lidar or close_by_camera):
            self.stop_robot()
            self.state = 'FINISHED'
            self.get_logger().info(
                f'Blue box reached. front_distance={self.front_distance:.2f}, '
                f'blue_area={self.blue_area:.0f}'
            )
            return

        cmd = Twist()

        if abs(error) > 0.18:
            cmd.linear.x = 0.0
            cmd.angular.z = -0.65 * error
        else:
            if self.front_distance > 1.8:
                cmd.linear.x = 0.16
            elif self.front_distance > 1.2:
                cmd.linear.x = 0.11
            else:
                cmd.linear.x = 0.06

            cmd.angular.z = -0.35 * error

        cmd.linear.x = max(min(cmd.linear.x, 0.18), 0.0)
        cmd.angular.z = max(min(cmd.angular.z, 0.55), -0.55)

        self.cmd_vel_pub.publish(cmd)


    def image_callback(self, data):
        try:
            frame = self.bridge.imgmsg_to_cv2(data, 'bgr8')
        except CvBridgeError as exc:
            self.get_logger().warn(f'Could not convert image: {exc}')
            return

        self.image_width = frame.shape[1]

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        red_mask = self.make_red_mask(hsv)
        green_mask = cv2.inRange(
            hsv,
            np.array([45, 80, 60]),
            np.array([85, 255, 255]),
        )
        blue_mask = cv2.inRange(
            hsv,
            np.array([95, 80, 60]),
            np.array([130, 255, 255]),
        )

        self.current_red = False
        self.current_green = False
        self.current_blue = False

        output = frame.copy()

        self.detect_colour(output, red_mask, 'red', (0, 0, 255))
        self.detect_colour(output, green_mask, 'green', (0, 255, 0))
        self.detect_colour(output, blue_mask, 'blue', (255, 0, 0))

        self.draw_status(output)

        cv2.imshow(self.window_name, output)
        cv2.waitKey(1)
        
    def scan_callback(self, msg):
        front_ranges = []

        for index, distance in enumerate(msg.ranges):
            angle = msg.angle_min + index * msg.angle_increment

            if abs(angle) <= FRONT_SCAN_HALF_ANGLE:
                if msg.range_min < distance < msg.range_max and math.isfinite(distance):
                    front_ranges.append(distance)

        if front_ranges:
            self.front_distance = min(front_ranges)


    def make_red_mask(self, hsv):
        lower_red_1 = np.array([0, 80, 60])
        upper_red_1 = np.array([10, 255, 255])
        lower_red_2 = np.array([170, 80, 60])
        upper_red_2 = np.array([180, 255, 255])

        mask_1 = cv2.inRange(hsv, lower_red_1, upper_red_1)
        mask_2 = cv2.inRange(hsv, lower_red_2, upper_red_2)
        return cv2.bitwise_or(mask_1, mask_2)

    def detect_colour(self, image, mask, colour_name, draw_colour):
        mask = cv2.erode(mask, None, iterations=1)
        mask = cv2.dilate(mask, None, iterations=2)

        contours, _ = cv2.findContours(
            mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )

        if not contours:
            return

        contour = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(contour)

        if area < MIN_AREA:
            return

        x, y, w, h = cv2.boundingRect(contour)
        centre_x = x + w // 2
        centre_y = y + h // 2

        if colour_name == 'red':
            self.current_red = True
            self.seen_red = True
        elif colour_name == 'green':
            self.current_green = True
            self.seen_green = True
        elif colour_name == 'blue':
            self.current_blue = True
            self.seen_blue = True
            self.blue_x = centre_x
            self.blue_area = area
            self.last_blue_time = time.time()

        cv2.rectangle(image, (x, y), (x + w, y + h), draw_colour, 2)
        cv2.circle(image, (centre_x, centre_y), 5, draw_colour, -1)
        cv2.putText(
            image,
            f'{colour_name}: {int(area)}',
            (x, max(20, y - 10)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            draw_colour,
            2,
            cv2.LINE_AA,
        )

    def draw_status(self, image):
        current = (
            f"Current: R={'Y' if self.current_red else 'N'} "
            f"G={'Y' if self.current_green else 'N'} "
            f"B={'Y' if self.current_blue else 'N'}"
        )
        seen = (
            f"Seen:    R={'Y' if self.seen_red else 'N'} "
            f"G={'Y' if self.seen_green else 'N'} "
            f"B={'Y' if self.seen_blue else 'N'}"
        )
        state = f'State: {self.state}'

        lines = [current, seen, state]

        for index, line in enumerate(lines):
            y = 30 + index * 25
            cv2.putText(
                image,
                line,
                (10, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )

    def stop_robot(self):
        self.cmd_vel_pub.publish(Twist())


def main():
    rclpy.init(args=None)
    node = ProjectNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop_robot()
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
